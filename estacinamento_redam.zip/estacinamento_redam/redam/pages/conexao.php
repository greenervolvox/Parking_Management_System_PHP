<?php
// Essa parte foi bem tranquilo de fazer. Estabeleci a conexão entre o localhost (Apache) e o programa. 
$usuario = 'root';
$senha = '';
$database = 'redam_sistema';
$host = 'localhost';

$mysqli = new mysqli($host, $usuario, $senha, $database);

if($mysqli->error) {
    die("Falha ao conectar ao banco de dados: " . $mysqli->error);
}