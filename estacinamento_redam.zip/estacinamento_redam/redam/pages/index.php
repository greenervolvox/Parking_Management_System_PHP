<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>REDAM — MENU</title>
    <link rel="stylesheet" href="../css/estilo.css">
</head>
<body class="body">
    <div class="menu-total">
<a href="index.php">
    <img width=300 src="../img/redam.jpg" alt="logo">
</a>
<!-- Criei diferentes rotas para as diferentes funções do programa... -->
    <form action="cadastrar_veiculo.php">
        <button class="botao" type="submit">CADASTRAR NOVO VEÍCULO</button>
    </form>
    <form action="registrar_entrada.php">
        <button class="botao" type="submit">REGISTRAR ENTRADA</button>
    </form>
    <form action="registrar_saida.php">
        <button class="botao" type="submit">REGISTRAR SAÍDA</button>
    </form>
    <form action="exibir_veiculos.php">
        <button class="botao" type="submit">EXIBIR HISTÓRICO (ENTRADA/SAÍDA)</button>
    </form>
</div>
</body>
</html>