<?php
include 'conexao.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nome = $_POST['nome'];

    $query = "INSERT INTO cadastro (nome) VALUES ('$nome')";

    if (mysqli_query($mysqli, $query)) {
        echo "Cadastro realizado com sucesso!";
    } else {
        echo "Erro ao cadastrar: " . mysqli_error($conn);
    }

    mysqli_close($mysqli);
} else {
    echo "Método inválido de acesso.";
}
?>