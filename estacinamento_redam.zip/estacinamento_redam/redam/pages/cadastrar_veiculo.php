<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastro de Veículo</title>
    <link rel="stylesheet" href="../css/estilo.css">
</head>
<body class="body">
    <!-- Criei as páginas nesta ordem: cadastro, entrada, saida e exibicao. As três primeiras foram muito desafiadores. 
    Boa parte da lógica PHP foi nova pra mim, e só entendi muita coisa ao final, depois de reanjar o que aprendia, com ajuda de material e IA. -->
<div class="menu-total">
    <a href="index.php">
    <img width=300 src="../img/redam.jpg" alt="logo">
</a>
<h4>CADASTRAR NOVO VEÍCULO</h4>
    <?php
    include 'conexao.php';

    $mensagem = '';
    $erro = '';
    //Coletando informações do formulário com método POST. Depois disso, crio variáveis para armazenar resultados de pesquisa
    //no Banco de Dados. Assim, posso saber se a placa já existe ou não (se a variável que computa o dado da placa for >1, já existe cadastro).
    //Essa página foi bem tranquila, o desafio começa nas duas páginas seguintes (na ordem que fiz na minha cabeça), que são entrada e saída.
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $nome_sobrenome = $_POST['nome_sobrenome'];
        $telefone_motorista = $_POST['telefone_motorista'];
        $placa_veiculo = $_POST['placa_veiculo'];
        $id_categoria = $_POST['id_categoria'];

        $sql_verificar_placa = "SELECT id_veiculo FROM RegistroVeiculo WHERE placa_veiculo = '$placa_veiculo'";
        $result_verificar_placa = $mysqli->query($sql_verificar_placa);

        if ($result_verificar_placa && $result_verificar_placa->num_rows > 0) {
            $erro = "Placa do veículo já cadastrada no sistema.";
        } else {
            $sql = "INSERT INTO RegistroVeiculo (nome_sobrenome, telefone_motorista, placa_veiculo, id_categoria) 
                    VALUES ('$nome_sobrenome', '$telefone_motorista', '$placa_veiculo', '$id_categoria')";

            if ($mysqli->query($sql) === TRUE) {
                $mensagem = "Veículo cadastrado com sucesso!";
            } else {
                $erro = "Erro ao cadastrar veículo: " . $mysqli->error;
            }
        }
    }

    $mysqli->close();
    ?>
    <div>
    <form class="formulario" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="POST">
        <label for="nome_sobrenome">Nome do motorista:</label>
        <input type="text" id="nome_sobrenome" name="nome_sobrenome" placeholder="Nome e sobrenome" required><br><br>
        
        <label for="telefone_motorista">Telefone do motorista:</label>
        <input type="number" id="telefone_motorista" name="telefone_motorista" placeholder="Somente números" required><br><br>
        
        <label for="placa_veiculo">Placa do Veículo:</label>
        <input type="text" id="placa_veiculo" name="placa_veiculo" maxlength="7" placeholder="ABC1234" required><br><br>
        
        <label for="id_categoria">Categoria do Veículo:</label> 
        <select id="id_categoria" name="id_categoria" required>
            <option value="">Selecione...</option>
            <option value="1">Carro</option>
            <option value="2">Moto</option>
            <option value="3">Caminhão</option>
            <option value="4">Van</option>
        </select><br><br>
        
        <input class="botao" type="submit" value="CADASTRAR">
    </form>
</div>
    <?php
    if ($mensagem) {
        echo "<p style='color: green;'>$mensagem</p>";
    }
    if ($erro) {
        echo "<p style='color: red;'>$erro</p>";
    }
    ?>

    <br>
    <form class="color" action="index.php" method="GET">
        <button class="botao" type="submit">VOLTAR PARA MENU</button>
    </form>
</body>
</html>