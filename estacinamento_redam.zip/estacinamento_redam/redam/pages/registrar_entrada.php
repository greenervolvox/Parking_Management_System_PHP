<?php
include 'conexao.php';

$mensagem = '';
$erro = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $placa_veiculo = $_POST['placa_veiculo'];

    // Aqui verifico se tem entrada ativa para o veículo na mesma data. Deixei a captura de data pelo sistema, e não preenchimento. Talvez
    //ter feito inserção de data e hora me ajudasse a resolver o problema que não consegui resolver, destaquei no documento ME_LEIA_ANTES, na pasta.
    // O resto do código é semelhante ao cadastrar_veiculo.php. Verifico se há dado ou não, para realizar entrada. E tbm preciso registrar +1 vez. Não alcancei este último feito em Saída..
    $sql_check_entrada = "SELECT id_entrada FROM EntradaVeiculo WHERE id_veiculo = (
        SELECT id_veiculo FROM RegistroVeiculo WHERE placa_veiculo = '$placa_veiculo'
    ) AND DATE(data_hora_entrada) = CURDATE()";

    $result_check_entrada = $mysqli->query($sql_check_entrada);

    if ($result_check_entrada->num_rows > 0) {
        // Verifico se o último registro de entrada foi sucedido por um registro de saída.
        $sql_check_saida_anterior = "SELECT id_saida FROM SaidaVeiculo WHERE id_entrada = (
            SELECT id_entrada FROM EntradaVeiculo WHERE id_veiculo = (
                SELECT id_veiculo FROM RegistroVeiculo WHERE placa_veiculo = '$placa_veiculo'
            ) AND DATE(data_hora_entrada) = CURDATE() ORDER BY data_hora_entrada DESC LIMIT 1
        )";

        $result_check_saida_anterior = $mysqli->query($sql_check_saida_anterior);

        if ($result_check_saida_anterior->num_rows == 0) {
            $erro = "Existe uma entrada ativa para o veículo com a placa $placa_veiculo na data de hoje, mas não foi registrado o último registro de saída. Registre a saída antes de abrir uma nova entrada.";
        } else {
            registrarEntrada($placa_veiculo);
        }
    } else {
        registrarEntrada($placa_veiculo);
    }
}

function registrarEntrada($placa_veiculo) {
    global $mysqli, $mensagem, $erro;

    // Reunindo info do BD para realizar o cálculo de taxa!! A taxa inicial é calculada aqui, e as horas suplementares lá em SAÍDA.
    $sql_info_veiculo = "SELECT id_veiculo, id_categoria FROM RegistroVeiculo WHERE placa_veiculo = '$placa_veiculo'";
    $result_info_veiculo = $mysqli->query($sql_info_veiculo);

    if ($result_info_veiculo && $result_info_veiculo->num_rows > 0) {
        $row_info = $result_info_veiculo->fetch_assoc();
        $id_veiculo = $row_info['id_veiculo'];
        $id_categoria = $row_info['id_categoria'];

        // Obter a taxa inicial da categoria do veículo
        $sql_taxa_inicial = "SELECT taxa_inicial FROM CategoriaVeiculo WHERE id_categoria = $id_categoria";
        $result_taxa_inicial = $mysqli->query($sql_taxa_inicial);

        if ($result_taxa_inicial && $result_taxa_inicial->num_rows > 0) {
            $row_taxa = $result_taxa_inicial->fetch_assoc();
            $taxa_inicial = $row_taxa['taxa_inicial'];

            // Inserir registro de entrada
            $sql_insert_entrada = "INSERT INTO EntradaVeiculo (id_veiculo, data_hora_entrada) VALUES ($id_veiculo, NOW())";

            if ($mysqli->query($sql_insert_entrada) === TRUE) {
                $mensagem = "Entrada registrada com sucesso! Taxa inicial: R$ " . number_format($taxa_inicial, 2);
            } else {
                $erro = "Erro ao registrar entrada: " . $mysqli->error;
            }
        } else {
            $erro = "Erro ao obter taxa inicial da categoria do veículo.";
        }
    } else {
        $erro = "Veículo com a placa $placa_veiculo não encontrado no sistema.";
    }
}

$mysqli->close();
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registrar Entrada de Veículo</title>
    <link rel="stylesheet" href="../css/estilo.css">
</head>
<body class="body">
    <div class="menu-total">
        <a href="index.php">
            <img width=300 src="../img/redam.jpg" alt="logo">
        </a>
        <h4>REGISTRAR ENTRADA DE VEÍCULO</h4>

        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="POST">
            <label for="placa_veiculo">Placa do Veículo:</label>
            <input type="text" id="placa_veiculo" name="placa_veiculo" maxlength="7" placeholder="ABC1234" required><br><br>
            
            <input class="botao" type="submit" value="REGISTRAR ENTRADA">
        </form>

        <?php
        if ($mensagem) {
            echo "<p style='color: green;'>$mensagem</p>";
        }
        if ($erro) {
            echo "<p style='color: red;'>$erro</p>";
        }
        ?>

        <br>
        <form action="index.php" method="GET">
            <button class="botao" type="submit">VOLTAR PARA MENU</button>
        </form>
    </div>
</body>
</html>