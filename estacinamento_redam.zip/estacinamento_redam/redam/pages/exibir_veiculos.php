<!DOCTYPE html>
<!-- Não tenho muito o que comentar aqui. Foi a última página que construí. Manipulação do BD, cálculos simples.. A mesma lógica de verificar espaço vazio e comparação. -->
<!--Geração de tabelas simples.-->
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Exibir Veículos</title>
    <link rel="stylesheet" href="../css/estilo.css">
</head>
<body class="body">
<div class="menu-total">
    <a href="index.php">
    <img width=300 src="../img/redam.jpg" alt="logo">
</a>
<h4>VEÍCULOS REGISTRADOS</h4>
    <?php
    include 'conexao.php';

    // Função para calcular o tempo de permanência
    function calcularTempoPermanencia($data_hora_entrada, $data_hora_saida) {
        $entrada = new DateTime($data_hora_entrada);
        $saida = new DateTime($data_hora_saida);
        $intervalo = $saida->diff($entrada);
        return $intervalo->format('%H:%I:%S');
    }

    $sql_exibir_veiculos = "SELECT rv.placa_veiculo, ev.data_hora_entrada, sv.data_hora_saida 
                            FROM RegistroVeiculo rv
                            INNER JOIN EntradaVeiculo ev ON rv.id_veiculo = ev.id_veiculo
                            LEFT JOIN SaidaVeiculo sv ON ev.id_entrada = sv.id_entrada
                            ORDER BY ev.data_hora_entrada DESC";

    $result_exibir_veiculos = $mysqli->query($sql_exibir_veiculos);

    if ($result_exibir_veiculos->num_rows > 0) {
        echo "<table border='1'>
                <tr>
                    <th>Placa do Veículo</th>
                    <th>Data e Hora de Entrada</th>
                    <th>Data e Hora de Saída</th>
                    <th>Tempo de Permanência</th>
                </tr>";

        while ($row = $result_exibir_veiculos->fetch_assoc()) {
            echo "<tr>
                    <td>" . $row['placa_veiculo'] . "</td>
                    <td>" . $row['data_hora_entrada'] . "</td>
                    <td>" . ($row['data_hora_saida'] ? $row['data_hora_saida'] : 'Veículo ainda não saiu') . "</td>
                    <td>" . ($row['data_hora_saida'] ? calcularTempoPermanencia($row['data_hora_entrada'], $row['data_hora_saida']) : 'N/A') . "</td>
                </tr>";
        }

        echo "</table>";
    } else {
        echo "Nenhum veículo registrado.";
    }

    $mysqli->close();
    ?>

    <br>
    <form action="index.php" method="GET">
        <button class="botao" type="submit">VOLTAR PARA MENU</button>
    </form>
</body>
</html>