-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Tempo de geração: 31/03/2024 às 20:54
-- Versão do servidor: 8.2.0
-- Versão do PHP: 8.2.13

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `redam_sistema`
--

-- --------------------------------------------------------

--
-- Estrutura para tabela `categoriaveiculo`
--

DROP TABLE IF EXISTS `categoriaveiculo`;
CREATE TABLE IF NOT EXISTS `categoriaveiculo` (
  `id_categoria` int NOT NULL AUTO_INCREMENT,
  `nome_categoria` varchar(50) NOT NULL,
  `taxa_inicial` decimal(10,2) NOT NULL,
  `adicional_por_hora` decimal(10,2) NOT NULL,
  PRIMARY KEY (`id_categoria`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Despejando dados para a tabela `categoriaveiculo`
--

INSERT INTO `categoriaveiculo` (`id_categoria`, `nome_categoria`, `taxa_inicial`, `adicional_por_hora`) VALUES
(1, 'Carro', 10.00, 2.00),
(2, 'Moto', 5.00, 1.00),
(3, 'Caminhão', 15.00, 3.00),
(4, 'Van', 20.00, 4.00);

-- --------------------------------------------------------

--
-- Estrutura para tabela `entradaveiculo`
--

DROP TABLE IF EXISTS `entradaveiculo`;
CREATE TABLE IF NOT EXISTS `entradaveiculo` (
  `id_entrada` int NOT NULL AUTO_INCREMENT,
  `id_veiculo` int NOT NULL,
  `data_hora_entrada` datetime NOT NULL,
  PRIMARY KEY (`id_entrada`),
  KEY `id_veiculo` (`id_veiculo`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `registroveiculo`
--

DROP TABLE IF EXISTS `registroveiculo`;
CREATE TABLE IF NOT EXISTS `registroveiculo` (
  `id_veiculo` int NOT NULL AUTO_INCREMENT,
  `nome_sobrenome` varchar(60) NOT NULL,
  `telefone_motorista` varchar(50) NOT NULL,
  `placa_veiculo` varchar(7) NOT NULL,
  `id_categoria` int NOT NULL,
  PRIMARY KEY (`id_veiculo`),
  KEY `fk_CatReg` (`id_categoria`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `saidaveiculo`
--

DROP TABLE IF EXISTS `saidaveiculo`;
CREATE TABLE IF NOT EXISTS `saidaveiculo` (
  `id_saida` int NOT NULL AUTO_INCREMENT,
  `id_entrada` int NOT NULL,
  `data_hora_saida` datetime NOT NULL,
  `valor_cobranca` decimal(10,2) NOT NULL,
  PRIMARY KEY (`id_saida`),
  KEY `id_entrada` (`id_entrada`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
