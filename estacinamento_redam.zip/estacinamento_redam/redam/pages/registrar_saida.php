<?php
// Essa foi a pior página, e não consegui fazer 100% do que queria aqui.
include 'conexao.php';

$mensagem = '';
$erro = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $placa_veiculo = $_POST['placa_veiculo'];

    // Verifico se existe uma entrada para a placa do veículo na data atual. Até aí, tudo bem.
    $sql_check_entrada = "SELECT id_entrada, id_veiculo FROM EntradaVeiculo WHERE id_veiculo = (
        SELECT id_veiculo FROM RegistroVeiculo WHERE placa_veiculo = '$placa_veiculo'
    ) AND DATE(data_hora_entrada) = CURDATE()";

    $result_check_entrada = $mysqli->query($sql_check_entrada);

    if ($result_check_entrada->num_rows == 0) {
        $erro = "Não foi encontrada entrada para o veículo com a placa $placa_veiculo.";
    } else {
        $row_entrada = $result_check_entrada->fetch_assoc();
        $id_entrada = $row_entrada['id_entrada'];

// Verificar se já existe saída registrada para esta entrada. Eu estava pensando em construir uma lógica que me permitisse registrar múltiplas entradas e saídas numa mesma data.
        $sql_check_saida = "SELECT id_saida FROM SaidaVeiculo WHERE id_entrada = $id_entrada";

        $result_check_saida = $mysqli->query($sql_check_saida);

        if ($result_check_saida->num_rows > 0) {
            $erro = "Já foi registrada a saída para esta entrada.";
        } else {
            registrarSaida($id_entrada);
        }
    }
}
// A parte de cobrança está ok, dentro desta função. Mas a parte relacionada a SAÍDA, lá embaixo, só funcionou para a primeira ENTRADA da data. Esta parte do código é bastante mérito da IA, mas decidi
// deixar aqui por uma questão de transparência.
function registrarSaida($id_entrada) {
    global $mysqli, $mensagem, $erro;

    // Calcular tempo de permanência
    $sql_calcular_horas = "SELECT TIMESTAMPDIFF(HOUR, data_hora_entrada, NOW()) AS horas_estacionadas FROM EntradaVeiculo WHERE id_entrada = $id_entrada";

    $result_calcular_horas = $mysqli->query($sql_calcular_horas);
    $row_horas = $result_calcular_horas->fetch_assoc();
    $horas_estacionadas = $row_horas['horas_estacionadas'];

    // Obter a categoria do veículo para calcular o valor da cobrança
    $sql_categoria_veiculo = "SELECT id_categoria FROM RegistroVeiculo WHERE id_veiculo = (
        SELECT id_veiculo FROM EntradaVeiculo WHERE id_entrada = $id_entrada
    )";
    $result_categoria_veiculo = $mysqli->query($sql_categoria_veiculo);
    $row_categoria = $result_categoria_veiculo->fetch_assoc();
    $id_categoria = $row_categoria['id_categoria'];

    // Obter taxa inicial e adicional por hora da categoria do veículo
    $sql_taxa_categoria = "SELECT taxa_inicial, adicional_por_hora FROM CategoriaVeiculo WHERE id_categoria = $id_categoria";
    $result_taxa_categoria = $mysqli->query($sql_taxa_categoria);

    if ($result_taxa_categoria && $result_taxa_categoria->num_rows > 0) {
        $row_taxa = $result_taxa_categoria->fetch_assoc();
        $taxa_inicial = $row_taxa['taxa_inicial'];
        $adicional_por_hora = $row_taxa['adicional_por_hora'];

        // Calcular valor de cobrança
        $valor_cobranca = $taxa_inicial + ($adicional_por_hora * $horas_estacionadas);

        // Inserir registro de saída
        $sql_insert_saida = "INSERT INTO SaidaVeiculo (id_entrada, data_hora_saida, valor_cobranca) 
                             VALUES ($id_entrada, NOW(), $valor_cobranca)";

        if ($mysqli->query($sql_insert_saida) === TRUE) {
            $mensagem = "Saída registrada com sucesso! Valor cobrado: R$ " . number_format($valor_cobranca, 2);
        } else {
            $erro = "Erro ao registrar saída: " . $mysqli->error;
        }
    } else {
        $erro = "Erro ao obter informações da categoria do veículo.";
    }
}

$mysqli->close();
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registrar Saída de Veículo</title>
    <link rel="stylesheet" href="../css/estilo.css">
</head>
<body class="body">
<div class="menu-total">
    <a href="index.php">
    <img width=300 src="../img/redam.jpg" alt="logo">
</a>
<h4>REGISTRAR SAÍDA DE VEÍCULO</h4>
    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="POST">
        <label for="placa_veiculo">Placa do Veículo:</label>
        <input type="text" id="placa_veiculo" name="placa_veiculo" maxlength="7" placeholder="ABC1234" required><br><br>
        
        <input class="botao" type="submit" value="REGISTRAR SAÍDA">
    </form>

    <?php
    if ($mensagem) {
        echo "<p style='color: green;'>$mensagem</p>";
    }
    if ($erro) {
        echo "<p style='color: red;'>$erro</p>";
    }
    ?>

    <br>
    <form action="index.php" method="GET">
        <button class="botao" type="submit">VOLTAR PARA MENU</button>
    </form>
</body>
</html>